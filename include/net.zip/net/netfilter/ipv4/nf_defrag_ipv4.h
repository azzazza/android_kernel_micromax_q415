#ifndef _NF_DEFRAG_IPV4_H
#define _NF_DEFRAG_IPV4_H

extern void nf_defrag_ipv4_enable(void);

#endif /* _NF_DEFRAG_IPV4_H */
